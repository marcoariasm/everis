export const environment = {
  production: true,
  baseUrl: 'https://fernando-herrera.com/api'
};
